# Steps {Localhost}
1. start xampp and start apache server as welll as sql server
2. go to phpmyadmin and upload sql to create database and tables
3. copy the project folder to your local htdocs folder
4. open any browser and simply type localhost/projectfoldername to run
5. displays landing page interface

# Steps{Backup}
