<div class="copy-right">
<p style="background: #1a2ab3; color: #fff; text-align: right; padding: 2%;"> 
&copy; 2023 OEP. All Rights Reserved | Design by Villemina Mashele - 59449292
</p>
</div>  
<!---->
<!--scrolling js-->
<script src="../js/jquery.nicescroll.js"></script>
<script src="../js/scripts.js"></script>
<!--//scrolling js-->
</body>
</html>